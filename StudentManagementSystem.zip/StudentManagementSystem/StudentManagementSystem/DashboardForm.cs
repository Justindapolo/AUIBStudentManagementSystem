﻿using System;
using System.Windows.Forms;

namespace StudentManagementSystem
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        // Event handler for ToolStripButton1
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ToolStrip Button 1 clicked!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Event handler for Button2 (Add Student)
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Add Student screen coming soon!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Existing event handlers
        private void btnViewStudents_Click(object sender, EventArgs e)
        {
            MessageBox.Show("View Students screen coming soon!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSearchStudents_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Search Students screen coming soon!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}