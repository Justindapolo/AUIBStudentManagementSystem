﻿using System;
using System.Windows.Forms;

namespace StudentManagementSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        // Hardcoded username & password
        private void btnLogin_Click(object sender, EventArgs e)
        {

            string username = "admin";
            string password = "1234";

            // Validating Info 
            if (txtUsername.Text == username && txtPassword.Text == password)
            {
                // if Success
                MessageBox.Show("Welcome to the Student Management System!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                DashboardForm dashboard = new DashboardForm();
                dashboard.Show();
                this.Hide(); 
            }
            else
            {
                // If Wrong
                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}